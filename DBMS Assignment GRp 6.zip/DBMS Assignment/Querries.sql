/*All transaction ID where transaction type is UPI (0)*/
SELECT 
    P.Transaction_ID
FROM
    Payment P
WHERE
    P.Transaction_Type = 0;

SELECT 
    COUNT(T.PNR_Number) AS 'No of tickets booked in train 1'
FROM
    ticket T
WHERE
    T.Train_Number = 1;

/*All male passanger starting their journey from Meerut station*/
SELECT 
    *
FROM
    Passenger P
WHERE
    P.Passenger_ID IN (SELECT 
            T.Passenger_ID
        FROM
            ticket T
        WHERE
            T.Source = 'Meerut')
        AND P.Gender = 'M';

SELECT 
    TS.Arrival_Time AS 'Train arrival time of passenger 9'
FROM
    train_schedule TS
WHERE
    (TS.Station_ID IN (SELECT 
            S.Station_ID
        FROM
            station S
        WHERE
            S.Station_Name IN (SELECT 
                    T.Source
                FROM
                    ticket T
                WHERE
                    T.Passenger_ID = 9))
        AND TS.Train_number IN (SELECT 
            T.Train_Number
        FROM
            ticket T
        WHERE
            T.Passenger_ID = 9));

/*platform no of all Female passengers whose age >= 18 and <= 54*/
SELECT 
    TS.Platform_No AS 'Platform no of all Female passengers whose age >= 18 and <= 54'
FROM
    train_schedule TS
WHERE
    (TS.Station_ID IN (SELECT 
            S.Station_ID
        FROM
            station S
        WHERE
            S.Station_Name IN (SELECT 
                    T.Source
                FROM
                    Ticket T
                WHERE
                    T.Passenger_ID IN (SELECT 
                            P.Passenger_ID
                        FROM
                            Passenger P
                        WHERE
                            (P.Gender = 'F' AND P.Age >= 18
                                AND P.Age <= 54))))
        AND TS.Train_number IN (SELECT 
            T1.Train_Number
        FROM
            Ticket T1
        WHERE
            T1.Passenger_ID IN (SELECT 
                    P.Passenger_ID
                FROM
                    Passenger P
                WHERE
                    (P.Gender = 'F' AND P.Age >= 18
                        AND P.Age <= 54))));
                        
/*Details of Passengers who is in 2nd AC and age is between 30 and 50 and whose PNR status is confirmed (1)*/
SELECT 
    *
FROM
    passenger P
WHERE
    P.Passenger_ID IN (SELECT 
            TS.Pid
        FROM
            train_status TS
        WHERE
            TS.Coach_No = 'B'
                AND TS.Pid IN (SELECT 
                    P.Passenger_ID
                FROM
                    passenger P
                WHERE
                    P.Age >= 30 AND P.age <= 50
                        AND P.PNR_Status = 1));
                        
/*Phone no of Users who has paid amount >= 1500 on or before 15-02-2022*/
SELECT 
    U.Phone_Number
FROM
    user U
WHERE
    U.User_ID IN (SELECT 
            P.User_ID
        FROM
            pays P
        WHERE
            P.Transaction_ID IN (SELECT 
                    P1.Transaction_ID
                FROM
                    payment P1
                WHERE
                    P1.Amount >= 1500
                        AND P1.Transaction_ID IN (SELECT 
                            P2.Transaction_ID
                        FROM
                            pays P2
                        WHERE
                            P2.Date <= '2022-02-15')));
                            
/*List of user names whose name starts with C and who canceled their ticket with refund >= 40*/
SELECT 
    U.Name
FROM
    user U
WHERE
    U.Name LIKE 'C%'
        AND U.User_ID IN (SELECT 
            C.U_ID
        FROM
            cancel C
        WHERE
            C.Refund_Percentage >= 40);

/*Details of all booked Seats*/
SELECT 
    TS.Train_no, TS.Coach_No, TS.Seat_No
FROM
    train_status TS
WHERE
    TS.Booking_Status = 1;

/*List of transaction ID where amount >= 2000*/
SELECT 
    P.Transaction_ID
FROM
    payment P
WHERE
    P.Amount >= 2000;






