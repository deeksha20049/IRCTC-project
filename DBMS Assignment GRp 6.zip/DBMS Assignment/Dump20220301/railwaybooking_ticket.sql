-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: railwaybooking
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `PNR_Number` int NOT NULL,
  `Train_Number` int NOT NULL,
  `Source` text NOT NULL,
  `Destination` text NOT NULL,
  `Date` date NOT NULL,
  `Passenger_ID` int NOT NULL,
  PRIMARY KEY (`PNR_Number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (12764,1,'Delhi','Mumbai','2022-03-01',24),(15518,2,'Jaipur','Nagpur','2022-03-01',35),(16156,3,'Patna','Madurai','2022-03-01',20),(16735,4,'Meerut','Bhiwandi','2022-03-01',26),(16988,5,'Gwalior','Raipur','2022-03-01',45),(17928,1,'Mumbai','Kolkata','2022-03-01',43),(18838,2,'Cawnpore','Indore','2022-03-01',49),(21481,3,'Jamshedpur','Faridabad','2022-03-01',25),(22395,4,'Meerut','Allahabad','2022-03-01',40),(25566,5,'Gwalior','Bareilly','2022-03-01',10),(25750,1,'Hyderabad','Lucknow','2022-03-01',36),(26376,2,'Vadodara','Chinchvad','2022-03-01',32),(26630,3,'Kalyan','Jamshedpur','2022-03-01',17),(28206,4,'Thane','Srinagar','2022-03-01',15),(33092,5,'Haora','Mysore','2022-03-01',42),(33702,1,'Surat','Lucknow','2022-03-01',28),(34503,2,'Mirzapur','Indore','2022-03-01',6),(36105,3,'Ludhiana','Aurangabad','2022-03-01',9),(37538,4,'Varanasi','Aligarh','2022-03-01',38),(38200,5,'Gwalior','Ranchi','2022-03-01',44),(40984,1,'Chennai','Ahmedabad','2022-03-01',29),(44649,2,'Indore','Vishakhapatnam','2022-03-01',11),(47805,3,'Aurangabad','Rajkot','2022-03-01',50),(48771,4,'Jabalpur','Srinagar','2022-03-01',7),(50130,5,'Bezwada','Raipur','2022-03-01',8),(51245,1,'Kolkata','Lucknow','2022-03-01',21),(52456,2,'Ghaziabad','Bhopal','2022-03-01',39),(52551,3,'Ludhiana','Rajkot','2022-03-01',3),(53972,4,'Allahabad','Aligarh','2022-03-01',12),(56378,5,'Kota','Bareilly','2022-03-01',23),(56561,1,'Bangalore','Ahmedabad','2022-03-01',46),(57061,2,'Bhopal','Chinchvad','2022-03-01',5),(61187,3,'Nasik','Aurangabad','2022-03-01',19),(64081,4,'Varanasi','Srinagar','2022-03-01',13),(68550,5,'Mysore','Kota','2022-03-01',34),(69118,1,'Bangalore','Chennai','2022-03-01',47),(69992,2,'Vadodara','Bhopal','2022-03-01',37),(70955,3,'Aurangabad','Rajkot','2022-03-01',16),(72453,4,'Aligarh','Bhiwandi','2022-03-01',4),(72990,5,'Bezwada','Raipur','2022-03-01',31),(73612,1,'Hyderabad','Surat','2022-03-01',14),(78900,2,'Nagpur','Indore','2022-03-01',48),(80401,3,'Madurai','Faridabad','2022-03-01',33),(80821,4,'Dhanbad','Aligarh','2022-03-01',18),(87272,5,'Kota','Bareilly','2022-03-01',22),(88017,1,'Pune','Ahmedabad','2022-03-01',27),(89820,2,'Ghaziabad','Chinchvad','2022-03-01',30),(90551,3,'Madurai','Rajkot','2022-03-01',41),(92799,4,'Allahabad','Bhiwandi','2022-03-01',1),(93818,5,'Bezwada','Bareilly','2022-03-01',2);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-01 20:58:26
